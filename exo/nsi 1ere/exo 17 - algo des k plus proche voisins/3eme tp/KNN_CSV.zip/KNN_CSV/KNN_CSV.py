# Créé par vstep, le 17/01/2020 en Python 3.4
# Créé par vstep, le 22/02/2019 avec EduPython
# K-NN algorithme : estimation de la fidélité d'un client à partir de ses k plus proches voisins
import csv # bibliothèque csv
from math import* # pour utiliser la racine carrée
##########################################################
# Ouverture du fichier csv
# et stockage dans une liste
with open('clients.csv','rt',newline="") as fichier:
    lecteurCSV=csv.reader(fichier,delimiter=",")
    tableau=[]
    for ligne in lecteurCSV:
        print(ligne)# pour vérification
        tableau.append(ligne)
fichier.close()

#print(tableau)#pour vérification
##########################################################
# Données du nouveau client
nom_nc='David'
age_nc=37
revenu_nc=50
achat_nc=2
classe = 1
##########################################################
# calcul et stockage dans une liste de tuples
# (distances de nouveau client aux autre clients , nom , fidélité)
liste=[]
for i in range(1,len(tableau),1):
    if tableau[i][5]=='0':
        d=sqrt((eval(tableau[i][1])-age_nc)**2+(eval(tableau[i][2])-revenu_nc)**2+(eval(tableau[i][3])-achat_nc)**2)
        liste.append((d,tableau[i][0],tableau[i][4]))
#tri de cette liste en fonction de la distance
liste.sort(key=lambda x:x[0])
print(liste)#pour vérification
###########################################################
# Déterminaison de la fidélité du nouveau client
# en fonction des k plus proches voisins
k=3
Co=0
Cn=0
for i in range(0,k,1):
    if liste[i][2]=='O':
        Co=Co+1
    if liste[i][2]=='N':
        Cn=Cn+1
if Co>Cn:
    F='O'
if Cn>Co:
    F='N'
print(nom_nc,"Fidélité : ",F," classe : " , classe)#pour vérification
#############################################################
# Rajout du nouveau client au tableau pour vérification
tmp=[nom_nc, age_nc, revenu_nc, achat_nc, F,classe]
tableau.append(tmp)
#print(tableau)
#############################################################
# Écriture d'un nouveau client dans le fichier clients.csv
# Important newline="" pour éviter la création d'une ligne vide...
with open('clients.csv','at',newline="") as fichier:
    ecrivainCSV = csv.writer(fichier,delimiter=",")
    ecrivainCSV.writerow(tmp)
fichier.close()

